from {{cookiecutter.snake}}.server import server  # noqa

server.launch()
